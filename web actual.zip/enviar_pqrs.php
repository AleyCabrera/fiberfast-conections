<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $tipo = $_POST['tipo'];
    $documento = $_POST['tipo_documento'];
    $numero = $_POST['numero_identificacion'];
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $mensaje = $_POST['mensaje'];

    /* GENERAR RADICADO */

    $radicado = 'PQRS-' . date('Ymd') . '-' . rand(1000, 9999);

    $mail = new PHPMailer(true);

    try {

        /* CONFIGURACIÓN DEL CORREO PRINCIPAL */

        $mail->CharSet = 'UTF-8';
        $mail->isMail();

        $mail->setFrom(
            'comercial@fiberfast.com.co',
            'PQRS FiberFast'
        );

        $mail->addAddress(
            'comercial@fiberfast.com.co'
        );

        $mail->Subject =
            "Nueva PQRS recibida - $radicado";

        $mail->Body = "
Número de Radicado: $radicado

Se ha recibido una nueva PQRS:

Tipo de solicitud: $tipo
Tipo de documento: $documento
Número de identificación: $numero
Nombre: $nombre
Teléfono: $telefono
Email: $email

Mensaje:
$mensaje
";

        /* ADJUNTAR ARCHIVO */

        if (
            isset($_FILES['adjunto']) &&
            $_FILES['adjunto']['error'] == 0
        ) {

            $archivo_tmp = $_FILES['adjunto']['tmp_name'];
            $archivo_nombre = $_FILES['adjunto']['name'];

            $mail->addAttachment(
                $archivo_tmp,
                $archivo_nombre
            );
        }

        /* ENVIAR CORREO A FIBERFAST */

        $mail->send();

        /* CORREO DE CONFIRMACIÓN AL CLIENTE */

        $mailCliente = new PHPMailer(true);

        $mailCliente->CharSet = 'UTF-8';
        $mailCliente->isMail();

        $mailCliente->setFrom(
            'comercial@fiberfast.com.co',
            'FiberFast'
        );

        $mailCliente->addAddress($email);

        $mailCliente->Subject =
            "Confirmación de PQRS - $radicado";

        $mailCliente->Body = "
Estimado(a) $nombre,

Hemos recibido correctamente su solicitud.

Número de Radicado:
$radicado

Tipo de solicitud:
$tipo

Conserve este número para futuras consultas.

Nuestro equipo revisará su caso y dará respuesta dentro de los tiempos establecidos.

Gracias por comunicarse con FiberFast.

Atentamente,

FiberFast
";

        $mailCliente->send();

        echo "<script>
        alert('Su PQRS fue registrada exitosamente.\\n\\nNúmero de Radicado: $radicado');
        window.location.href='page/pqrs.html';
        </script>";

    } catch (Exception $e) {

        echo 'Error al enviar el mensaje: ' . $mail->ErrorInfo;
    }
}
?>

